package com.market.service;

import com.market.model.Student;

import java.util.List;

public interface IStudentService {
    List<Student> getAllStudent();
}
