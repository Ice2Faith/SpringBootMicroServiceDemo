package com.market.dao;

import com.market.model.Student;

import java.util.List;

public interface IStudentDao {
    List<Student> getAll();
}
