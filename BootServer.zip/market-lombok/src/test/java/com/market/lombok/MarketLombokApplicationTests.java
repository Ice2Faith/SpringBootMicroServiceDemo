package com.market.lombok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketLombokApplicationTests {

	@Test
	void contextLoads() {
	}

}
