package com.market.redis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
