package com.zuul.eureka.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulEurekaClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
